<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejer 4 - Img por pantalla</title>
</head>
<body>
    <h1>hola</h1>
    <!-- <img src="" alt=""> -->
    <?php 
    $img = '<img src="../img/terrerneitor.jpg" alt="Terreneitor">';
        echo $img;
    ?>
</body>
</html>