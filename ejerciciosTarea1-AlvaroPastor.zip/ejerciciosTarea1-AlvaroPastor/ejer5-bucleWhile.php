<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ej 5 - Bucle while</title>
</head>
<body>
    <?php 
    
    $contador = 0;

    while ($contador <= 15) {
        # code...
        echo $contador;
        $contador++;
    }
    
    ?>
</body>
</html>