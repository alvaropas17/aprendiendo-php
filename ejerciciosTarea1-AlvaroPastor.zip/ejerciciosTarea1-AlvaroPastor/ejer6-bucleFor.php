<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ej 6 - Bucle for</title>
</head>
<body>
    <?php 
    
    $contador = 0;

    for ($i=10; $i < 10 ; $i++) { 
        # code...
        echo $i;
    }
    
    ?>
</body>
</html>