<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ej 10 - Variabes por pantalla</title>
</head>
<body>
    <h3>Definir una variable de cada tipo: integer, double, string y boolean. Luego imprimirlas en la pagina, una por línea.
</h3>

<?php 

    $int = 15;
    $double = 12.3;
    $str = "hola";
    $boolean = false;

    echo $int . "</br>";
    echo $double . "</br>";
    echo $str . "</br>";
    echo $boolean . "</br>";

?>
</body>
</html>