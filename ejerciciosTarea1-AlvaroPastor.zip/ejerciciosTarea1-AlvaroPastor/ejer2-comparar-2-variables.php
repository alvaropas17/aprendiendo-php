<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejer 2 Comparar variables</title>
</head>
<body>
    <?php 
        $var = 45;
        $var2 = 20;

        if($var > $var2){
            echo "$var es mayor que $var2";
        } else {
            echo "$var es menor o igual que $var2";
        }
    
    ?>
</body>
</html>