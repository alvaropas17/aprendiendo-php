<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejer 3 Suma variables</title>
</head>
<body>
    <?php 
        $var1 = 56;
        $var2 = 87;

        $sumaVariables = $var1 + $var2;

        echo "La suma de $var1 y $var2 es = $sumaVariables";
    ?>
</body>
</html>